package feladat2;

/**
 *
 * @author Reni
 */

/**
 * Az osztály n oldalú szabályos sokszögek reprezentálására szolgál.
 * Attribútumai a sokszög oldalainak száma és hossza, és középpontját meghatározó két koordináta.
 * Metódusai a sokszögek létrehozására szolgáló konstruktorok, a sokszögek adattagjainak lekérdező és beállító metódusai,
 * a sokszögek területét és kerületét visszaadó metódusok, illetve egy sztringreprezentáció.
 */

public class RegularPolygon {
    
    private int n;  //oldalak száma
    private double side;    //oldalak hossza
    private double x;   // x koord
    private double y;   //y koord

    
    /**
    * Ez egy speciális metódus, egy paraméter nélküli konstruktor,
    * amely egy n oldalú szabályos sokszöget hoz létre az alapértelmezett értékekkel.
    */
    
    public RegularPolygon() {
        
        this.n = 3;
        this.side = 1;
        this.x = 0;
        this.y = 0;
    }
    
    /**
    * Ez egy speciális metódus, egy paraméteres konstruktor, amelynek két paramétere a sokszög oldalszáma és oldalhossza.
    * Egy n oldalú szabályos sokszöget hoz létre a paraméterben megadott értékekkel,
    * melynek középpontját alapértelmezetten a (0,0) pontba állítja.
    */
    
    /**
     *  Ez egy speciális metódus, egy paraméteres konstruktor, amelynek két paramétere a sokszög oldalszáma és oldalhossza.
     * Egy n oldalú szabályos sokszöget hoz létre a paraméterben megadott értékekkel,
     * melynek középpontját alapértelmezetten a (0,0) pontba állítja.
     * @param n - oldalak száma
     * @param side - oldalak hossza
     */
    
    public RegularPolygon(int n, double side) {
        this.n = n;
        this.side = side;
        this.x = 0;
        this.y = 0;
    }
    
    /**
    * Ez egy speciális metódus, egy paraméteres konstruktor, amelynek 4 paramétere a sokszög oldalszáma és oldalhossza,
    * illetve a középpontot meghatározó x és y koordináták.
    * Egy n oldalú szabályos sokszöget hoz létre a paraméterben megadott értékekkel.
    */
    
    /**
     * Ez egy speciális metódus, egy paraméteres konstruktor, amelynek 4 paramétere a sokszög oldalszáma és oldalhossza,
     * illetve a középpontot meghatározó x és y koordináták.
     * Egy n oldalú szabályos sokszöget hoz létre a paraméterben megadott értékekkel.     * 
     * @param n - oldalak száma
     * @param side - oldalak hossza
     * @param x - x koord.
     * @param y - y koord.
     */
    
    public RegularPolygon(int n, double side, double x, double y) {
        this.n = n;
        this.side = side;
        this.x = x;
        this.y = y;
    }

    public int getN() {
        return n;
    }

    public void setN(int n) {
        this.n = n;
    }

    public double getSide() {
        return side;
    }

    public void setSide(double side) {
        this.side = side;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }
    
    /**
     * A metódus visszaad egy valós számot, a sokszög kerületét.
     * Egy szabályos sokszög kerületét a következő képlettel lehet meghatározni: K = oldalhossz * oldalszám
     * @return oldalhossz * oldalszám
     */
    
    public double getPerimeter(){   //kerület
        return this.n * this.side;
    }
    
    /**
     * A metódus visszaad egy valós számot, a sokszög területét.
     * Egy szabályos sokszög területét a következő képlettel lehet meghatározni: (n*s^2)/(4*tan(π/n))
     * @return (n*s^2)/(4*tan(π/n))
     */
    
    public double getArea(){
        return (this.n * (this.side * this.side)) / (4.0 * Math.tan((Math.PI / this.n)));
    }
    
    /**
     * Felülírásra került a toString metódus, amely kiírja a sokszög oldalainak számát és hosszát,és középpontjának koordinátáit ebben a sorrendben
     * @return oldalszám, oldalhossz, x koordináta, y koordináta
     */

    @Override
    public String toString() {
        return n + " oldalú sokszög oldalainak hossza " + side + "cm, koordinátái: (" + x + ", " + y + ')';
    }
    
}
