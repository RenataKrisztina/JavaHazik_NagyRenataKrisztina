/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package feladat2;

/**
 *
 * @author Reni
 */

/**
 * A Main osztály csak a fő függvényt tartalmazza, melyben létrehozunk 3 különböző szabályos sokszöget 3 különböző konstruktorral.
 * Ezután kíratjuk a létrejött objektumok területét és kerületét.
 */
public class Main {
    
    public static void main(String[] args) {
        
        RegularPolygon r1 = new RegularPolygon();
        RegularPolygon r2 = new RegularPolygon(6,4);
        RegularPolygon r3 = new RegularPolygon(10,4,5.6,7.8);
        
        //System.out.println(r1);
        //System.out.println(r2);
        //System.out.println(r3);
        
        System.out.println(r1.getArea());
        System.out.println(r2.getArea());
        System.out.println(r3.getArea());
        System.out.println();
        System.out.println(r1.getPerimeter());
        System.out.println(r2.getPerimeter());
        System.out.println(r3.getPerimeter());
    }
}
