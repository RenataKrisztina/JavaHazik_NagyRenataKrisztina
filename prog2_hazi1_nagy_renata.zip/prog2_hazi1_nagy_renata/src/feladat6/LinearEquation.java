/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package feladat6;

/**
 *
 * @author Reni
 */

/**
 * Ez az osztály a valós világ beli 2x2-es egyenletrendszert kívánja modellezni.
 * Attribútumai az egyenletek valós paraméterei.
 * Megadja, hogy az egyenletrendszer megoldható-e vagy sem, illetve az egyenletrendszer megoldásait visszaadó metódusokat.
 */

public class LinearEquation {
    
    private double a, b, c, d, e, f;    //parameterek az egyenletrendszerben

    public LinearEquation(double a, double b, double c, double d, double e, double f) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
    }

    public double getA() {
        return a;
    }

    public double getB() {
        return b;
    }

    public double getC() {
        return c;
    }

    public double getD() {
        return d;
    }

    public double getE() {
        return e;
    }

    public double getF() {
        return f;
    }
    
    /**
    * A metódus vissza ad egy igazságértéket annak megfelelően, hogy az egyenletrendszer megoldható-e vagy sem.
    * Az egyenletrendszer nem megoldható, ha az a*d - b*c érték egyenlő nullával
    * @return true / false
    */
    
    public boolean isSolvable(){
        if( a*d - b*c == 0){
            return false;
        }
        else
            return true;
    }
    
    /**
    * A metódus vissza ad egy valós számot, ami az egyenletrendszer egyik megoldása (x).
    * @return (e*d - b*f) / (a*d - b*c)
    */
    
    public double getX(){
        return (e*d - b*f) / (a*d - b*c);
    }
    
    /**
    * A metódus vissza ad egy valós számot, ami az egyenletrendszer egyik megoldása (y).
    * @return (a*f - e*c) / (a*d - b*c)
    */
    
    public double getY(){
        return (a*f - e*c) / (a*d - b*c);
    }
    
    
    
    
    
    
    
    
}
