package feladat6;

/**
 *
 * @author Reni
 */

/**
 * A Main osztály csak a fő függvényt tartalmazza, melyben létrehozunk 3 különböző egyenletrendszer objektumot.
 * Mindhárom esetben megvizsgálja, hogy megoldhatóak-e az egyenletrendszerek,
 * majd ennek megfelelően kiíratja a megoldásokat vagy a "The equation has no solution." üzenetet.
 */

public class Main {
    
    public static void main(String[] args) {
        LinearEquation lin1 = new LinearEquation(1,2,3,4,5,6);
        LinearEquation lin2 = new LinearEquation(0,0,3,4,5,6);
        LinearEquation lin3 = new LinearEquation(4.5,2.3,3,1,6,6);
        
        if( lin1.isSolvable() == false){
            System.out.println("The equation has no solution.");
        }else
            System.out.println(lin1.getX() + ", " + lin1.getY());
        
        if( lin2.isSolvable() == false){
            System.out.println("The equation has no solution.");
        }else
            System.out.println(lin2.getX() + ", " + lin2.getY());
        
        if( lin3.isSolvable() == false){
            System.out.println("The equation has no solution.");
        }else
            System.out.println(lin3.getX() + ", " + lin3.getY());
    }
}
