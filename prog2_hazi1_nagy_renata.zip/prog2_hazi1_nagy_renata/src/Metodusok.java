

/**
 *
 * @author Reni
 */

/**
 * A Metódusok osztály tartalmazza a main statikus függvényt, illetve további 14 statikus metódust.
 * A 14 statikus metódus meghívásra kerül a main-be.
 */

public class Metodusok {
    
    public static void main(String[] args) {
        
        //novekvo(3,1,2);
        //min_MaxAbs(2.3,4.5,1);
        //System.out.println(szokoevek(2010, 2012));
        //System.out.println(osztas(6,2));
        //sorrend(4,5,1,-2);
        //System.out.println(haromszogEgyenlotlenseg(2,7,9));
        //System.out.println(prim_1(8));
        //fibonacci_2(5);
        //System.out.println(forditottSzam(987654));
        //System.out.println(faktorialis(5));
        //oszthatoKval(2,1,10);
        //System.out.println(legkisebbFibonacci(6));
        ezernelKisebbSzamok();
    }
    
    // 1.
    
    /**
     * @param a (egész szám)
     * @param b (egész szám)
     * @param c (egész szám)
     * 
     * A metódus paraméterként kap 3 egész számot(a, b, és c), és ezeket íratja ki növekvő sorrendben.
     * A paraméterként kapott 3 egész számot belehelyezzük egy tömbbe, majd egymásba ágyazott for ciklus segítségével növekvő sorba rendezzük a tömb elemeit.
     * Végül szintén egy for ciklus segítségével kiíratjuk a tömb elemeit.
     */
    public static void novekvo(int a, int b, int c){
        
        int[] tomb = {a,b,c} ;
        int csere;
        for( int i = 0; i < tomb.length - 1; i++){
            for(int j = i +1; j < tomb.length; j++){
                if( tomb[i] > tomb[j]){
                    csere = tomb[i];
                    tomb[i] = tomb[j];
                    tomb[j] = csere;
                }
            }  
        }
        for( int i = 0; i < tomb.length; i++){
            System.out.println(tomb[i]);
        }
                
    }
    
    // 2.
    
    /**
     * A metódus paraméterként kap 3 valós számot(a, b, és c), és ezeket íratja ki a minimumát, és abszolút értékük maximumát.
     * A paraméterként kapott 3 valós számot belehelyezzük egy tömbbe, 
     * majd egymásba ágyazott for ciklus segítségével növekvő sorba rendezzük a tömb elemeit. Így a tömb első eleme biztosan a legkisebb szám lesz - a minimum.
     * Kiíratjuk a tömbünk első elemét ( tomb[0]).
     * A Math osztály abs függvényével meghatározzuk az elemek azbszolút értéket, melyeket eltárolunk egy tömbben.
     * A fenti módszerhez hasonóan rendezzük az új tömbünket és kiíratjuk a tömbünk utolsó elemét, azaz a maximumot (tomb[2]).
     * 
     * @param a (valós szám)
     * @param b (valós szám)
     * @param c (valós szám)
     */
    public static void min_MaxAbs(double a, double b, double c){
        
        double[] tomb = {a,b,c} ;
        double csere;
        for( int i = 0; i < tomb.length - 1; i++){
            for(int j = i +1; j < tomb.length; j++){
                if( tomb[i] > tomb[j]){
                    csere = tomb[i];
                    tomb[i] = tomb[j];
                    tomb[j] = csere;
                }
            }  
        }
        
        System.out.println("Minimum= " + tomb[0]);
        
        double[] tomb2 = {Math.abs(a),Math.abs(b),Math.abs(c)} ;
        for( int i = 0; i < tomb2.length - 1; i++){
            for(int j = i +1; j < tomb2.length; j++){
                if( tomb2[i] > tomb2[j]){
                    csere = tomb2[i];
                    tomb2[i] = tomb2[j];
                    tomb2[j] = csere;
                }
            }  
        }
        System.out.println("Abszolut ertekek maximuma= " + tomb2[2]);       
    }
    
    // 3.
    
    /**
     * A metódus paraméterként kapott 4 valós számot íratja ki 2 féle sorrendben.
     * Először kiíratásra kerül az eredeti sorrend (a,b,c,d), 
     * majd a d érték függvényében a paraméterek kiíratásának sorrrendje:
     * ha d nagyobb vagy egyenlo mint 0 - sorrend: a,c,b,d
     * egyébként - sorrend: a,c,b,d
     * @param a (tetszőleges valós szám)
     * @param b (tetszőleges valós szám)
     * @param c (tetszőleges valós szám)
     * @param d (tetszőleges valós szám)
     */
    public static void sorrend(double a, double b, double c, double d){
        
        System.out.println(a + " " + b + " " + c + " " +d);
        
        if( d >= 0){
            System.out.println(a + " " + c + " " + b + " " +d);
        }else
            System.out.println(a + " " + b + " " + d + " " +c);
        
    }
    
    
    // 4.
    
    /**
    * A metódus visszaadja, hogy egy háromszög megszerkeszthető-e vagy sem, 
    * azaz bármely oldalának hossza kisebb-e a másik két oldal hosszának összegénél.
    * A háromszög oldalainak hossza a paraméterben megadott valós számok.
    * Visszatérési értéke egy igazságérték(true vagy false).
    * @param a (valós szám)
    * @param b (valós szám)
    * @param c (valós szám)
    * @return true / false
    */
    
    public static boolean haromszogEgyenlotlenseg(double a, double b, double c){
        if( a < b+c && b < a+c && c < a+b)
            return true;
        else
            return false;
    }
    
    
    // 5.
    
    /**
     * A metódus visszaadja, hogy hány szökőév volt/lesz két különböző évszám között, melyeket paraméterként adunk meg a metódusnak.
     * Először meghatározásra kerül, hogy melyik a kisebb év, majd for ciklus segítségével végig lépkedünk a 2 évszám közötti éveken,
     * és megnézzük melyekre teljesül az alábbi feltétel: osztható 4-gyel és nem osztható 100-zal, vagy osztható 400-zal
     * Számláló segítségével tartjuk számon hány évszámra teljesül a feltétel.
     * @param ev1 (tetszőleges évszám)
     * @param ev2 (tetszőleges évszám)
     * @return számláló - a szökőévek számát megadó egész szám
     */
    public static int szokoevek(int ev1, int ev2){
        
        int szamlalo = 0;
        int kisebb;
        int nagyobb;
        
        if( ev1 <= ev2){
            kisebb = ev1;
            nagyobb = ev2;
        } else{
            kisebb = ev2;
            nagyobb = ev1;
        }
         
        for( int i = kisebb; i <= nagyobb; i++){
                if( (i%4 == 0 && i%100 != 0) || i%400 == 0){
                    szamlalo++;
                }
        }
        
        return szamlalo;
    }
    
    // 6.
    
    /**
     * Az eljárás paraméterként megkap egy egész számot (a dolgozatra adott jegyet),
     * és kiírja a dolgozat szöveges értékelését az érdemjegy alapján.
     * Ha az eljárás paraméternek nem egy 1 és 5 közötti egész számot kap,
     * akkor kírja, hogy "hiba".
     * A metódusnak nincs visszatérési értéke.
     * @param jegy (egész szám 1 és 5 között)
     */
    
    public static void osztalyzat(int jegy){
        switch(jegy){
            case 1:System.out.println("elégtelen"); break;
            case 2:System.out.println("elégséges"); break;
            case 3:System.out.println("közepes"); break;
            case 4:System.out.println("jó"); break;
            case 5:System.out.println("jeles"); break;
            default: System.out.println("hiba"); break;
        }
    }
    
    
    // 7.
    
    /**
     * A metódus meghatározza a paraméterként megadott két természetes szám hányadosát ismételt kivonásokkal
     * @param a (természetes szám)
     * @param b (természetes szám)
     * @return hányados
     */
    
    public static double osztas(int a, int b){
        double hanyados = 0;
        
        while( a >= b){
            hanyados = hanyados + 1;
            a = a - b;
        }
        
        return hanyados;
    }
    
    
    // 8.
    
    /**
     * A metódus megmondja a paraméterként kapott természetes számról, hogy prímszám-e vagy sem.
     * A metódus azt vizsgálja, hogy hány osztója van az n paraméternek, 
     * mert egy természetes szám akkor prím, ha csak 1-gyel és önmagával osztható.
     * @param n (természetes szám)
     * @return igazságérték - true/false
     */
    
    public static boolean prim_1(int n){
        
        int osztok_szama = 0;
        
        for( int oszto = 1; oszto <= n; oszto++){
            if( n % oszto == 0){
                osztok_szama = osztok_szama+1;
            }
        }
        
        if( osztok_szama == 2)
            return true;
        else
            return false;
    }
    
    /**
     * A metódus megmondja a paraméterként kapott természetes számról, hogy prímszám-e vagy sem.
     * A metódus azt vizsgálja, hogy hány osztója van az n paraméternek 2 és négyzetgyök n között.
     * @param n (természetes szám)
     * @return igazságérték - true/false
     */
    
    /*
    public static boolean prim_2(int n){
        
        return true;
        
        for( int oszto = 2; oszto <= Math.sqrt(n); oszto++){
            if( n % oszto == 0){
                return false;
            }
        }

    }*/
    
    
    // 9.
    
    /**
     * A metódus kiírja az első n fibonacci számot, ahol n a metódus paramétere.
     * 3 változó segítségével generálja a fibonacci számokat.
     * minden szám a megelőző kettő tagnak az összege.
     * @param n (egész szám)
     */
    
    public static void fibonacci_1(int n){
        
        int a = 0;
        int b = 1;
        
        if( n == 1){
            System.out.println(a);
        }
        else if( n == 2){
            System.out.println(a);
            System.out.println(b);
        }
        else{
            int c = a + b;
            System.out.println(a);
            System.out.println(b);
            System.out.println(c);
            int k = 3;
            while(k < n){
                a = b;
                b = c;
                c = a + b;
                System.out.println(c);
                k = k + 1;
            }
        }
    }
    
    /**
     * A metódus kiírja az első n fibonacci számot, ahol n a metódus paramétere.
     * 2 változó segítségével generálja a fibonacci számokat(a,b).
     * minden szám a megelőző kettő tagnak az összege.
     * @param n (egész szám)
     */
    
    public static void fibonacci_2(int n) {
        
        int a = 1;
        int b = 0;
        
        for( int k = 1; k <= n; k++){
            System.out.println(b);
            b = a + b;
            a = b - a;
        }
        
    }
    
    // 10.
    
    /**
     * A metódus egy legfeljebb 9 jegyű természetes szám számjegyeit adja vissza fordított sorrendben
     * @param n - legfeljebb 9 jegyű természetes szám
     * @return ujSzam - egész szám, az eredeti szám számjegyei fordított sorrenden
     */
    
    public static int forditottSzam(int n) {
        
        int ujSzam = 0;
        while( n != 0){
            ujSzam = ujSzam * 10 + n % 10;
            n = n / 10;
        }
        return ujSzam;
    }
    
    // 11.
    
    /**
     * A metódus paraméterként kap egy 0 és 12 közötti számot és visszaadja annak a faktoriálisát.
     * A metódus 1-től n-ig összeszorozza a számokat.
     * @param n - 0 és 12 közötti szám
     * @return faktorialis - egész szám, a számok 1től n-ig összeszorozva
     */
    
    public static int faktorialis( int n) {
        
        int faktorialis = 1;
        
        for( int i = 1; i <= n; i++){
            faktorialis = i * faktorialis;
        }
        
        return faktorialis;
    }
    
    // 12.
    
    /**
     * A metódus kiírja az összes k paraméterrel osztható számot, amelyek két adott szám (n1 és n2, az eljárás paraméterei) között találhatók.
     * A metódus megvizsgálja az n1 és n2 közötti számok közül melyek azok amik k-val osztva nulla maradékot adnak, és kiírja őket standard kimenetre.
     * @param k (egész szám, az osztó)
     * @param n1 (egész szám)
     * @param n2 (egész szám)
     */
    public static void oszthatoKval(int k, int n1, int n2) {
        
        int kisebb;
        int nagyobb;
        
        if( n1 <= n2){
            kisebb = n1;
            nagyobb = n2;
        }else{
            kisebb = n2;
            nagyobb = n1;
        }
        
        for( int i = kisebb; i <= nagyobb; i++){
            if( i % k == 0)
                System.out.println(i);
        }
        
    }
    
    // 13.
    
    /**
     * A metódus megkeresi azt a legkisebb Fibonacci-számot, amely nagyobb, mint egy adott n szám (paraméter).
     * @param n (tetszőleges természetes szám)
     * @return b - egész szám, a legkisebb Fibonacci-számot, amely nagyobb, mint az n paraméter
     */
    
    public static int legkisebbFibonacci(int n){
        int a = 0;
        int b = 1;
        
        if( n < 0){
            return a;
        }
        while( b <= n){
            b = a + b;
            a = b - a; 
        }
        return b;
    }
    
    // 14.
    
    /**
     * A metódus megkeresi azokat az 1000-nél kisebb számokat, 
     * amelyek egyenlők számjegyeik köbének összegével, és kiírja őket standard kimenetre.
     */
    
    public static void ezernelKisebbSzamok(){
        int maradek = 0;
        int hanyados = 0;
        int osszeg = 0;
        
        for( int i = 0; i < 1000; i++){
            hanyados = i;
            osszeg = 0;
            while( hanyados > 0){
                maradek = hanyados % 10;
                osszeg += maradek * maradek * maradek;
                hanyados = (int)(hanyados/10);
            }
            if( osszeg == i){
                System.out.println(i);
            }
        }
        
    }
    
    

    
}
