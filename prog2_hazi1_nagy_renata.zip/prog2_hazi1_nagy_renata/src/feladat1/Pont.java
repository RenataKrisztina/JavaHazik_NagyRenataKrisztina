package feladat1;

/**
 *
 * @author Nagy Renáta Krisztina
 */

/**
 * Ez az osztály két dimenziós pontok modellezésére szolgál.
 * Attribútumai a pont valós koordinátái(x és y), melyek privát láthatósági szinttel rendelkeznek,
 * metódusai a pontot létrehozó konstruktor és a pontok koordinátáit beállító és lekérdező metódusok,
 * mivel ezek privát adatmezők és nem érhetőek el közvetlenül.
 */

public class Pont {
    
    private double x;
    private double y;
    
    /**
     * Ez egy speciális metódus, egy paraméteres konstruktor, amelynek 2 paramétere a pont valós koordinátái.
     * Egy pontot hoz létre a megadott koordinátákkal, ha meghívásra kerül a főfüggvényben
     * @param x - a pont valós x koord-ja
     * @param y - a pont valós y koord-ja
     */

    public Pont(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }
    
}
