/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package feladat1;

/**
 *
 * @author Reni
 */

/**
 * A Main osztály csak a fő függvényt tartalmazza, melyben létrehozunk 4 pontot.
 * Módosítjuk mind a 4 pont valamely koordinátáját, majd kiíratjuk képernyőre a módosított koordinátájú pontokat.
 */


public class Main {
    
    public static void main(String[] args) {
        
        //„hozzunk a világra” 4 darab pontot
        Pont p1 = new Pont(1,0);
        Pont p2 = new Pont(3,2);
        Pont p3 = new Pont(1,3);
        Pont p4 = new Pont(6,2);
        
        //első két pont y koordinátáját az eredeti érték+5-re módosítjuk
        p1.setY(p1.getY()+5);
        p2.setY(p2.getY()+5);
        
        //második két pont x koordinátáját előző érték-3.4-re módosítjuk
        p3.setX(p3.getX()-3.4);
        p4.setX(p4.getX()-3.4);
        
        //kiíratások
        System.out.println(p1.getY());
        System.out.println(p2.getY());
        System.out.println(p3.getX());
        System.out.println(p4.getX());
        
    }
    
}
