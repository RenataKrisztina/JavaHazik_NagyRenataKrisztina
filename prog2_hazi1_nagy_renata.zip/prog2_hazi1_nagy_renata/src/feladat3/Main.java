/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package feladat3;

/**
 *
 * @author Reni
 */

/**
 * A Main osztály csak a fő függvényt tartalmazza, melyben létrehozunk 2 téglalapot.
 * Módosítjuk mind a 2 téglalap valamelyik attribútumát, 
 * majd kiíratjuk képernyőre a módosított téglalapukat a toString metódusban meghatározottaknak megfelelően.
 */
public class Main {
    
    public static void main(String[] args) {
        
        Rectangle r1 = new Rectangle(4,40);
        Rectangle r2 = new Rectangle(3.5,35.9);
        
        System.out.println(r1);
        System.out.println(r2);
        
    }
}
