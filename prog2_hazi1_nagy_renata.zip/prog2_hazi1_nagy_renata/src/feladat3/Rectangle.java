package feladat3;

/**
 *
 * @author Reni
 */

/**
 * Ez az osztály téglalapokat reprezentál.
 * Attribútumai a téglalap magassága és szélessége.
 * Metódusai két különböző konstruktor, a téglalapok területét és kerületét visszaadó metódusok illetve egy sztringreprezentáció.
 */

public class Rectangle {
    
    public double width;
    public double height;
    
    /**
    * Ez egy speciális metódus, egy paraméter nélküli konstruktor,
    * amely egy téglalap objektumot hoz létre az alapértelmezett értékekkel.
    */
    
    public Rectangle()
    {
        this.height= 1.0;
        this.width= 1.0;
    }
    
    /**
    * Ez egy speciális metódus, egy paraméteres konstruktor, amelynek két paramétere a téglalap szélessége és magassága.
    * Egy n téglalapot hoz létre a paraméterben megadott értékekkel.
    */
    
    /**
     * Ez egy speciális metódus, egy paraméteres konstruktor, amelynek két paramétere a téglalap szélessége és magassága.
     * Egy n téglalapot hoz létre a paraméterben megadott értékekkel. 
     * @param w - valós szám, a téglalap szélessége
     * @param h - valós szám, a téglalap hosszúsága
     */
    
    public Rectangle(double w, double h)
    {
        this.height = h;
        this.width = w;
    }
    
    /**
     * A metódus visszaad egy valós számot, a téglalap területét.
     * Egy téglalap területét a következő képlettel lehet meghatározni: T = magasság * szélesség
     * @return magasság * szélesség
     */
    
    public double getArea()
    {
        return this.height*this.width;
    }
    
    /**
     * A metódus visszaad egy valós számot, a téglalap kerületét.
     * Egy téglalap kerületét a következő képlettel lehet meghatározni: T = 2*(magasság + szélesség)
     * @return 2*(magasság + szélesség)
     */
    
    public double getPerimeter()
    {
        return 2*(this.height+this.width);
    }
    
    /**
     * Felülírásra került a toString metódus, amely kiírja a téglalapk szélességét, magasságát, területét, kerületét ebben a sorrendben
     * @return szélesség, magasság, terület, kerület
     */

    @Override
    public String toString() {
        return "width=" + this.width + ", height=" + this.height +  ", Area=" + this.getArea() + ", Perimeter=" + this.getPerimeter();
    }
}
