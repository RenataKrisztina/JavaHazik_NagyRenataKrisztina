package feladat4;

import java.util.Date;
import java.util.Objects;

/**
 *
 * @author Reni
 */

/**
 * Ez az osztály italokat kíván modellezni.
 * Az italok attribútumai: név, kiszerelés, ár(statikus), gyártási dátum.
 * Az osztály get és set metódusokat tartalmaz, melyek segítségével lekérdezhetőek és beállíthatóak a privát adattagok.
 * Az osztály megadja, hogy az italok mennyibe kerülnek euróba átváltva, illetve megad egy sztringreprezentációt is.
 */
public class Ital {
    
    protected String név;
    protected String kiszerelés;
    private static int ár = 10;
    protected Date gyártásiDátum;
    
    /**
    * Ez egy speciális metódus, egy paraméteres konstruktor,
    * amely paraméterként megkapja egy ital nevét és kiszerelését.
    * A gyártási dátum nem kerül átadásra paraméterként a konstruktornak, az az ital objektum létrehozásának időpontját fogja tárolni.
    */

    public Ital(String név, String kiszerelés) {
        this.név = név;
        this.kiszerelés = kiszerelés;
        this.gyártásiDátum = new Date();
    }

    public String getNév() {
        return név;
    }

    public void setNév(String név) {
        this.név = név;
    }

    public String getKiszerelés() {
        return kiszerelés;
    }

    public void setKiszerelés(String kiszerelés) {
        this.kiszerelés = kiszerelés;
    }

    public static int getÁr() {
        return ár;
    }

    public static void setÁr(int ár) {
        Ital.ár = ár;
    }

    public Date getGyártásiDátum() {
        return gyártásiDátum;
    }

    public void setGyártásiDátum(Date gyártásiDátum) {
        this.gyártásiDátum = gyártásiDátum;
    }
    
    /**
    * A metódus vissza ad egy valós számot, hogy az ital alapértelmezetten forintban értendőt ára mennyi euró.
    * @return ár /360.0 (jelenleg 1 euró kb. 360 forint)
    */
    public static double getÁrEuróban(){
        return Ital.ár / 360.0;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }
    
    /** 
     * Felül definiáltam az equals metódust, úgy hogy két ital objektum akkor legyen egyenlő, ha nevük, kiszerelésük és az áruk is megegyezik.
     * @return megegyezik-e a két név és megegyezik-e a két kiszerelés
     */

    @Override
    public boolean equals(Object obj) {
        
        if(obj == null || !( obj instanceof Ital) ){
            return false;
        }
        
        Ital i = (Ital)obj;
        
        return this.név.equals(i.getNév()) && this.kiszerelés == i.getKiszerelés();
    }
    
    
    
    
    /** 
     * Felül definiáltam a toString() metódust úgy, hogy az ital adatait az alábbi formában adja vissza: név, kiszerelés, ár Ft.
     */
    @Override
    public String toString() {
        return név + ", " + kiszerelés + ", " + ár + " Ft";
        
        
    }
    
    
    
    
    
}
