/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package feladat4;

/**
 * Main osztályt és main metódust nem kért a feladatsor, csak ellenőrzés miatt készítettem.
 * Létrehozok két ital objektumok, kiíratom őket, kiíratom az árukat euróban átváltva, majd összahasonlítom őket.
 * @author Reni
 */



public class Main {
    
    public static void main(String[] args) {
        
        Ital i1 = new Ital("Coca-cola", "3 dl");
        Ital i2 = new Ital("Coca-cola", "3 dl");
        System.out.println(i1);
        System.out.println(Ital.getÁrEuróban());
        System.out.println(i1.equals(i2));
        
    }
}
