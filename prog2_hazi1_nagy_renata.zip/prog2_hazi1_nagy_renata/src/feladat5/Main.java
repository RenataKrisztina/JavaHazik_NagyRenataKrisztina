/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package feladat5;

/**
 *
 * @author Reni
 */

/**
 * A Main osztály csak a fő függvényt tartalmazza, melyben létrehozunk 3 QuadraticEquation objektumot.
 * Majd kiíratjuk a három objektumot, amelyek a toString() metódusban megírtak alapján 
 * a diszkrimináns értékétül függően különböző alakokban fognak kiíródni.
 */

public class Main {
    
    public static void main(String[] args) {
        
        QuadraticEquation e1 = new QuadraticEquation(1, -6, 10);
        QuadraticEquation e2 = new QuadraticEquation(3, -14, 8);
        QuadraticEquation e3 = new QuadraticEquation(4, 12, 9);
        
        System.out.println(e1);
        System.out.println();
        System.out.println(e2);
        System.out.println();
        System.out.println(e3);

    }
    
}
