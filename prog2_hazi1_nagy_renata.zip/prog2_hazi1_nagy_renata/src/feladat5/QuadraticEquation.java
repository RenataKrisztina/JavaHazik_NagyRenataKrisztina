package feladat5;

/**
 *
 * @author Reni
 */

/**
 * Ez az osztály a valós világ beli másodfokú egyenleteket kívánja modellezni.
 * Attribútumai a másodfokú egyenlet együtthatói.
 * Megadja az egyenlet diszkriminánsát, gyökeit és sztringreprezentációját.
 * @author Reni
 */

public class QuadraticEquation {
    
    private double a;       
    private double b;
    private double c;

    public QuadraticEquation(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public double getA() {
        return a;
    }

    public double getB() {
        return b;
    }

    public double getC() {
        return c;
    }
    
    /**
    * A metódus visszaad egy valós számot, ami a másodfokú egyenlet diszkriminánsa.
    * A diszkrimináns értéke fogja meghatározni a másodfokú egyenlet gyökeinek számát:
    * D nagyobb, mint 0, 2 megoldása van az egyenletnek.
    * D = 0, 1 megoldása van az egyenletnek.
    * D negatív, nincs valós megoldása az egyenletnek.
    * @return - A másodfokú egyenlet diszkriminánsa: b^2-4ac
    */
    
    public double getDiscriminant(){
        
        return this.b*this.b-4*this.a*this.c;
    }
    
    /**
    * A metódus visszaadja a másodfokú egyenlet egyik gyökét, ha a diszkrimináns nem negatív.
    * Ha negatív a diszkrimináns, akkor erről egy üzenettel tájékoztataja a felhasználót és vissza ad egy nulla értéket is.
    * @return - a másodfokú egyenlet első gyöke: -b + gyök alatt( b^2 - 4ac)
    */
    
    public double getRoot1()
    {
        if( this.getDiscriminant() < 0){
            System.out.println("negativ diszkriminans");
            return 0;
        }else{
        return (-this.b+Math.sqrt(this.getDiscriminant()))/(2*this.a);
        }
    }
    
    /**
    * A metódus visszaadja a másodfokú egyenlet egyik gyökét, ha a diszkrimináns nem negatív.
    * Ha negatív a diszkrimináns, akkor erről egy üzenettel tájékoztataja a felhasználót és vissza ad egy nulla értéket is.
    * @return - a másodfokú második gyöke: -b - gyök alatt( b^2 - 4ac)
    */
    
    public double getRoot2()
    {
        if( this.getDiscriminant() < 0){
            System.out.println("negativ diszkriminans");
            return 0;
        }else{
        return (-this.b-Math.sqrt(this.getDiscriminant()))/(2*this.a);
        }
    }
    
    /**
    * A metódus kiírja a másodfokú egyenlet három együtthatóját, és a diszkrimináns értékétől függően az egyenlet egy vagy két megoldását.
    * Ha a diszkrimináns értéke negatív, akkor az egyenletnek nem lehetnek valős gyökei,
    * ezért megoldások helyett a "The equation has no solution." üzenetet írja ki.
    */

    @Override
    public String toString() {

        if(this.getDiscriminant() < 0){
            return "a=" + a + ", b=" + b + ", c=" + c + "\n" + "The equation has no solution.";
        }
        if(this.getDiscriminant() == 0){
            return "a=" + a + ", b=" + b + ", c=" + c + "\n" + "x=" + this.getRoot1();
        }else{
            return "a=" + a + ", b=" + b + ", c=" + c + "\n" + "x1=" + this.getRoot1() + ", x2=" + this.getRoot2();
        }
        
    }
}
